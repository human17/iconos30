# iconos30
Este es el repositorio de los códigos de la generación 30 de la Maestría en Comunicación con Medios Virtuales de ICONOS.
