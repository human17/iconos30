(function ($) {
	$.fn.extend({
		onePageScrolling : function (opcionesUsuario) {
			var opcionesIniciales = {
				velocidad : 1000,
				direccion : 'vertical'  //horizontal
			},
				opc = $.extend(opcionesIniciales, opcionesUsuario)

			function inicializar() {
				//alert('funciona')
				function aDondeScroll(evento) {
					evento.preventDefault()

					var idEnlace = $(this).attr('href'),
						coordsSeccion

					/*
						console.log(
							idEnlace,
							coordsSeccion
						)
					*/

					if(opc.direccion == 'vertical')
					{
						coordsSeccion = $(idEnlace).offset().top

						$('html, body').animate({
							scrollTop: coordsSeccion
						}, opc.velocidad)
					} 
					else
					{
						coordsSeccion = $(idEnlace).offset().left
						
						$('html, body').animate({
							scrollLeft: coordsSeccion
						}, opc.velocidad)
					}
				}

				$(this).on('click', aDondeScroll)
			}

			return $(this).each( inicializar )
		}
	})

	$(document).on('ready', function () {
		if($('.wrapper').attr('data-horizontal')) 
		{
			var numSecciones = $('.wrapper').children().length,
				anchoWrapper = (numSecciones * 100).toString() + 'vw'

			console.log(
				$('.wrapper').children().length,
				anchoWrapper
			)

			$('.wrapper').css({width:anchoWrapper})
			$('.section').addClass('horizontal')
			$('body').css({overflow:'hidden'})
		}
	})
})(jQuery)