//Función anónima autoejecutable
(function ($) {
	//jQuery le hereda todas sus características al nuevo objeto
	$.fn.extend({
		//Nombre del componente
		plugin : function (opcionesUsuario) {
			//Opciones por defecto del componente
			var opcionesIniciales = {
				fondo : 'orangered',
				colorLetra : 'navy',
				letra : '2rem'
			},
				//$.extend() nos permite extender las opciones iniciales del plugin con las que posiblemente mande el usuario
				opc = $.extend(opcionesIniciales, opcionesUsuario)

			//Función constructora del componente donde irá toda la programación del mismo
			function inicializar()
			{
				//alert('funciona')
				$(this).css({
					backgroundColor : opc.fondo,
					color : opc.colorLetra,
					fontSize : opc.letra 
				})
			}

			//Por cada elemento que invoque el componente, se debe ejecutar una vez la función constructora
			return $(this).each( inicializar )
		}
	})
})(jQuery)