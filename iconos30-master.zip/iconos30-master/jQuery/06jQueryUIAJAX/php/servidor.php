<?php 
echo '<p>Hemos recibido tu información , en breve nos pondremos en contacto</p>';