function enviarDatos(e) {
	e.preventDefault();

	$.ajax({
		url:'php/servidor.php',
		method : 'POST', //GET o POST
		data: $(this).serialize(),
		beforeSend : function () {
			//alert('Antes de enviar')
			$('#precarga').fadeIn('slow');
		},
		error : function () {
			//alert('Ocurrió un error')
			$('#precarga').fadeOut('slow', function (){
				$('#mensaje')
					.fadeIn('slow')
					.html('Ocurrió un error')
			});
		},
		success : function (data) {
			//alert('Exito el servidor contestó: ' + data)
			$('#precarga').fadeOut('slow', function (){
				$('#mensaje')
					.fadeIn('slow')
					.html(data)
			});
		}
	});

	console.log(
		$(this),
		$(this).serialize()
	)
}