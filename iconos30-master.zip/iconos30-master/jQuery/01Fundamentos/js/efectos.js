/*
alert('funciona')
jQuery('selector') o $('selector')
Tipos de selectores:
	objetos js
	etiquetas html
	id css
	clases css
	pseudo clases y pseudo elementos css

//Evento semántico
window.onload = function () {
	alert('ha cargado la página')
	document.body.style.backgroundColor = 'black';
	document.body.style.color = 'greenyellow';
}
//Evento múltiples (listeners)
window.addEventListener('load', function () {
	alert('ha cargado la página')
	document.body.style.backgroundColor = 'black';
	document.body.style.color = 'greenyellow';	
})

//Evento semántico con jQuery
$(window).load(function () {
	alert('ha cargado la página con jQuery')
	$('body').css({
		backgroundColor : 'black',
		color : 'greenyellow'
	});
});

//Evento múltiples (listeners) con jQuery
$(window).on('load', function () {
	alert('ha cargado la página con jQuery')
	$('body').css({
		backgroundColor : 'black',
		color : 'greenyellow'
	});	
})
//Cargar el documento en jQuery
window -> load
document -> ready
*/
function efectos() {
	$('p').on('click', function (){
		$(this).hide()
	})

	$('#boton').on('click', function (){
		$('p').show()
	})

	$('p').css('background-color','yellow')

	$('#boton2').on('click', function (){
		$('p').hide(2000)
	})

	$('#boton3').on('click', function (){
		$('p').show('slow') /* fast, slow y swing */
	})

	$('#boton4').on('click', function (){
		$('p').toggle()
	})

	$('#boton5').on('click', function (){
		$('p').toggle('swing')
	})

	$('.mostrar').on('click', function (){
		$('.deslizante').slideDown(1500)
	})

	$('.ocultar').on('click', function (){
		$('.deslizante').slideUp('fast')
	})

	$('.mostrar-ocultar').on('click', function (){
		$('.deslizante').slideToggle()
	})

	$('#boton6').on('click', function () {
		$('#cuadro').fadeTo(3000, .25)
	})

	$('#boton7').on('click', function (){
		$('#cuadro').fadeTo('slow', 1)
	})

	$('#boton8').on('click', function (){
		$('#cuadro').fadeOut('slow')
	})

	$('#boton9').on('click', function (){
		$('#cuadro').fadeIn(2000)
	})

	$('#parpadea').on('click', function (){
		$('#cuadro').fadeOut().fadeIn()
		/*
		setInterval(function () {
			$('#cuadro').fadeOut().fadeIn();
		}, 1000);
		*/
	})
	
	$('#boton10').on('click', function () {
		$('#animable')
			.animate({height : 300}, 'slow')
			.animate({width : 300}, 1500)
			.animate({height : 100, width : 100}, 3000)
	})
	
	$('#boton11').on('click', function () {
		$('#animable')
			.animate({left : '50%'}, 'swing')
			.animate({width : 400}, 1000)
			.animate({'font-size' : '3rem'}, 'fast')
			.animate({fontSize : '2rem'}, 'slow')
			.animate({backgroundColor : '#123456'}, 500)
			.animate({color : 'red'}, 'swing')
			.animate({top : -100}, 1200)
			.animate({
				'font-size' : '1rem',
				left : 0,
				top : 0,
				width : 100,
				backgroundColor : '#EC673A',
				color : 'black'
			}, 5000)
	})

	$('#boton12').on('click', function () {
		/*
		$('#oculto').hide(2000)
		alert('El párrafo se ha ocultado')
		*/

		//función callback
		$('#oculto').hide(2000, function () {
			alert('El párrafo se ha ocultado')	
		})
	})

	/*
	antes .before()
	<selector>
		antes .prepend()
		CONTENIDO .html()
		después .append()
	</selector>
	después .after()
	*/
	$('#boton13').on('click', function (){
		$('p').html('<i>El contenido ha sido cambiado</i>')
	})

	$('#boton14').on('click', function (){
		$('p').prepend('<b>Contenido agregado antes</b><img src="http://cursos.bextlan.com/img/jquery.png"> ')
	})

	$('#boton15').on('click', function (){
		$('p').append(' <b>contenido agregado después</b><input type="text">')
	})

	$('#boton16').on('click', function (){
		$('p').before('<div class="antes">Contenido agregado antes del selector</div>')
		$('.antes').css('background-color', 'magenta')
	})

	$('#boton17').on('click', function (){
		$('p').after('<div class="despues">Contenido agregado después del selector</div>')
		$('.despues').css('background-color', 'cyan')
	})

	$('#boton18').on('click', function (){
		$('p')
			.css('font-size', '2rem')
			.css({backgroundColor : 'skyblue'})
	})

	$('#boton19').on('click', function (){
		$('p').css({
			'background-color' : '#EEE',
			borderRadius : '1rem',
			border : 'thick solid #222',
			fontSize : '2rem',
			padding : '1rem',
			'text-shadow' : '.2rem .2rem .5rem #000'
		})
	})

	/*
	$('#enlace').on('click', function () {})
	$('#enlace').on('mouseover', function () {})
	$('#enlace').on('mouseout', function () {})
	*/
	$('#enlace').on({
		click : function (evento) {
			evento.preventDefault();
			alert('He prevenido la acción del enlace')
		},
		mouseover : function () {
			//$('span').addClass('span-css')
			$('span').toggleClass('span-css')
		},
		mouseout : function () {
			//$('span').removeClass('span-css')
			$('span').toggleClass('span-css')
		}
	})

	$('#boton20').on('click', function (){
		//$('#ajax').load('otro.html')
		$('#ajax').load('otro.html #logo')
	})

	$('#boton21').on('click', function (){
		$('#ajax').load('otro.html #logo', function () {
			$('#logo')
				.css({display:'none'})
				.fadeIn(2000)
		})
	})

	$('#que-tecla').on('keyup', function (evento){
		$('#codigo-tecla').text(evento.keyCode)
	})

	$('#subir').on('click', function () {
		$('html, body').animate({
			scrollTop : 0,
			scrollLeft : 0
		},1000)
	})
}//cierra efectos

function muevete(evento) {
	//console.log(evento)
	//console.log(evento.keyCode)
	switch (evento.keyCode) {
		case 37:
			evento.preventDefault();
			$('#pacman').animate({left:'-=2rem'}, 'swing')
			break;
		case 38:
			evento.preventDefault();
			$('#pacman').animate({top : '-=2rem'}, 'swing')
			break;
		case 39:
			evento.preventDefault();
			$('#pacman').animate({left:'+=2rem'}, 'swing')
			break;
		case 40:
			evento.preventDefault();
			$('#pacman').animate({top : '+=2rem'}, 'swing')
			break;
	}
}

function detectarScroll() {
	var scrollVertical = $(window).scrollTop(),
		scrollHorizontal = $(window).scrollLeft()

	//console.log( scrollVertical, scrollHorizontal )

	return (scrollVertical > 100) ? $('#subir').fadeIn() : $('#subir').fadeOut()
}

$(document)
	.on('ready', efectos)
	.on('keydown', muevete)

$(window).on('scroll', detectarScroll)