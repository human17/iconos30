<?php 
echo '<h1>Este es un Hola Mundo desde PHP cargado por AJAX</h1>';