<?php 
interface Ingredientes {
	public function establecer_ingredientes($lista);
	public function obtener_ingredientes();
}