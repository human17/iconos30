<?php
//Si no encuentra el archivo manda warning, error fatal y detiene la ejecución del script
require('./Telefono.php');
require('./Celular.php');
require('./SmartPhone.php');
//Si no encuentra el archivo manda warning y sigue con la ejecución del script
//include('./Telefono.php');  

echo '<h1>Evolución del Teléfono</h1>';

echo '<h2>Teléfono:</h2>';
$tel_casa = new Telefono('Panasonic', 'KX-TS550');
$tel_casa->llamar();
$tel_casa->mas_info();

echo '<h2>Celular:</h2>';
$mi_cel = new Celular('Nokia', '5120');
$mi_cel->llamar();
$mi_cel->mas_info();

echo '<h2>SmartPhone:</h2>';
$mi_sp = new SmartPhone('Motorola', 'G3');
$mi_sp->llamar();
$mi_sp->mas_info();