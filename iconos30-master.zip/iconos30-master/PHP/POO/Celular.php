<?php
//extends me permite heredar las características de una clase a otra
class Celular extends Telefono {
	protected $alambrico = false;

	public function __construct($marca, $modelo) {
		parent::__construct($marca, $modelo);
	}
}