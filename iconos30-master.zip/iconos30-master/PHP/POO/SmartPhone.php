<?php
final class SmartPhone extends Celular {
	public $internet = true;

	public function __construct($marca, $modelo) {
		parent::__construct($marca, $modelo);
	}

	//Polimorfismo : Es la capacidad que da a diferentes objetos, la posibilidad de contar con métodos y atributos de igual nombre, sin que los de un objeto interfieran con el de otro
	public function mas_info() {
		return print('
			<ul>
				<li>Marca <b>' . $this->marca . '</b></li>
				<li>Modelo <b>' . $this->modelo . '</b></li>
				<li>Comunicación <b>' . $this->comunicacion . '</b></li>
				<li>Dispositivo con Acceso a Internet</li>
			</ul>
		');
	}
}