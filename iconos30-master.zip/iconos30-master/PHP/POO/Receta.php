<?php 
interface Receta {
	public function establecer_receta($pasos);
	public function obtener_receta();
}