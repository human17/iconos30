<?php 
class Postre implements Ingredientes, Receta {
	private $ingredientes;
	private $receta;
	
	public function establecer_receta($pasos) {
		$this->receta = explode('|', $pasos);
	}
	
	public function obtener_receta() {
		$num_pasos = count($this->receta);

		$html = '<ol>';
		for ($i=0; $i < $num_pasos; $i++) { 
			$html .= '<li>' . $this->receta[$i] . '</li>';
		}
		$html .= '</ol>';

		return print($html);
	}

	public function establecer_ingredientes($lista) {
		$this->ingredientes = explode(',', $lista);
	}

	public function obtener_ingredientes() {
		//echo $this->ingredientes;
		//var_dump($this->ingredientes);
		//echo count($this->ingredientes);
		$num_ingredientes = count($this->ingredientes);

		$html = '<ul>';
		for ($i=0; $i < $num_ingredientes; $i++) { 
			$html .= '<li>' . $this->ingredientes[$i] . '</li>';
		}
		$html .= '</ul>';

		return print($html);
	}
}