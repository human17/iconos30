<?php 
abstract class Model {
	private static $db_host = 'localhost';
	private static $db_user = 'root';
	private static $db_pass = '';
	private static $db_name = 'mexflix30';
	private static $db_charset = 'utf8';
	private $conn;
	protected $sql;
	protected $rows = array();

	abstract protected function set();
	abstract protected function get();
	abstract protected function del();

	private function db_open() {
		//http://es.php.net/manual/es/class.mysqli.php
		$this->conn = new mysqli(
			self::$db_host,
			self::$db_user,
			self::$db_pass,
			self::$db_name
		);

		$this->conn->set_charset(self::$db_charset);
	}

	private function db_close() {
		$this->conn->close();
	}

	protected function set_query() {
		$this->db_open();
		$this->conn->query($this->sql);
		$this->db_close();
	}

	protected function get_query() {
		$this->db_open();
		
		$result = $this->conn->query($this->sql);
		//Devuelve un arreglo posicional, tengo que saber la posición que ocupa el campo en la tabla
		//while( $this->rows[] = $result->fetch_row() );
		//Devuelve un arreglo asociativo, con saber el nombre del campo basta
		while( $this->rows[] = $result->fetch_assoc() );
		$result->close();
		
		$this->db_close();

		return array_pop($this->rows);
	}
}