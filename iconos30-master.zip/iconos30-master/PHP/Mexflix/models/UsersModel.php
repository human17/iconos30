<?php 
class UsersModel extends Model {
	public function set( $users_data = array() ){
		foreach ($users_data as $key => $value) {
			//Variables Variables
			//http://php.net/manual/es/language.variables.variable.php
			$$key = $value;
		}

		$this->sql = "REPLACE INTO users (user, email, name, birthday, pass, role) VALUES ('$user', '$email', '$name', '$birthday', MD5('$pass'), '$role')";
		$this->set_query();
	}

	public function get( $user = '' ){
		$this->sql = ( $user == '' )
			?"SELECT * FROM users"
			:"SELECT * FROM users WHERE user = '$user'";

		$this->get_query();

		$num_rows = count($this->rows);

		$data = array();

		foreach($this->rows as $key => $value) {
			array_push($data, $value);
		}

		return $data;
	}

	public function del( $user = '' ){
		$this->sql = "DELETE FROM users WHERE user = '$user'";
		$this->set_query();
	}

	public function validate_user($user, $pass){
		$this->sql = "SELECT * FROM users WHERE user = '$user' AND pass = MD5('$pass')";

		$this->get_query();

		$data = array();

		foreach($this->rows as $key => $value) {
			array_push($data, $value);
		}

		return $data;
	}

	public function __destruct() {
		unset($this);
	}
}

/*
$users = new UsersModel();
var_dump( $users->get('@jonmircha') );
$new_users = array(
	'users_id' => 6,
	'users' => 'Other users'
);
*/

//$users->set($new_users);
//$users->del(6);