<?php 
print('
	<h2 class="p1  error">Error 404: URL NO ENCONTRADA</h2>
	<img class="p1  img-404" src="./public/img/not-found.png" alt="Recurso No Encontrado">
');