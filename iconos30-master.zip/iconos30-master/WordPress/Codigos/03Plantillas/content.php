		<article class="item  lg-flex-auto  ph12  lg9  content">
			<?php 
				/*
				Búsquedas Personalizadas en el Loop
				http://www.anieto2k.com/2008/01/13/query_posts-personalizando-nuestros-blogs/
				https://codex.wordpress.org/Class_Reference/WP_Query#Parameters
				query_posts('order=ASC&posts_per_page=10&category_name=grandes');
				*/

				if( have_posts() ):
					while( have_posts() ):
						the_post();
						//echo '<p>Imprimiendo info de mi publicación</p>';
			?>
			<article class="post">
				<a href="<?php the_permalink(); ?>">
					<h2 class="post-title">
						<?php the_title(); ?>
					</h2>
				</a>
				<?php the_excerpt(); ?>
				<p>
					<?php //the_date(); ?>
					<small>
						<i class="fa  fa-calendar"></i>
						<?php the_time('d-M-Y g:i a'); ?>
					</small>
				</p>
				<p>Categorías:</p>
				<?php the_category(); ?>
				<p><?php the_tags(); ?></p>
				<p>
					<a href="<?php print get_author_posts_url( get_the_author_id() ); ?>">
						<i class="fa  fa-user"></i>
						<?php the_author(); ?>
					</a>
				</p>
				<?php 
					if ( is_page() || is_single() ) {
						print('<div class="content-section">');
							the_content();
						print('</div>');
					}
				
					if ( is_single() ) {
						print('<section class="comments-section">');
							comments_template();
						print('</section>');
					}
				?>
			</article>
			<hr>
			<?php
					endwhile;
				else:
					echo '<p class="error">No hay publicaciones</p>';
				endif;
				rewind_posts();
			?>
		</article>