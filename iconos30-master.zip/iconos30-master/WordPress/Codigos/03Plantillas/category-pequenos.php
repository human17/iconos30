<?php 
get_header();
print('
	<article class="item  title-template">
		<p>
			El archivo <em>category-pequenos.php</em> es el archivo que toma por defecto WordPress para mostrar la categoría con el slug "pequeños" en la BD.
		</p>
	</article>
');
get_template_part('content');
get_sidebar();
get_footer();