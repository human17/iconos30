<?php 
get_header();
print('
	<article class="item  title-template">
		<p>
			El archivo <em>category-4.php</em> es el archivo que toma por defecto WordPress para mostrar la categoría con el id 4 (gigantes) en la BD.
		</p>
	</article>
');
get_template_part('content');
get_sidebar();
get_footer();