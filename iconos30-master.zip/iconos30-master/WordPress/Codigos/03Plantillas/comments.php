<?php 
print('<ol>');
	wp_list_comments();
print('</ol>');
comment_form();