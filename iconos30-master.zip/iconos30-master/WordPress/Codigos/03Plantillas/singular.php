<?php 
get_header();
print('
	<article class="item  title-template">
		<p>
			El archivo <em>singular.php</em> es el archivo que toma por defecto WordPress para mostrar entradas y páginas estáticas.
		</p>
	</article>
');
get_template_part('content');
get_sidebar();
get_footer();