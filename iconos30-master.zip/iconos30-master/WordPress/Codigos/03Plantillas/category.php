<?php 
get_header();
print('
	<article class="item  title-template">
		<p>
			El archivo <em>category.php</em> es el archivo que toma por defecto WordPress para mostrar categorías.
		</p>
	</article>
');
get_template_part('content');
get_sidebar();
get_footer();