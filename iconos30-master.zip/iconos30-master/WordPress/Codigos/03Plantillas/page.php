<?php 
get_header();
print('
	<article class="item  title-template">
		<p>
			El archivo <em>page.php</em> es el archivo que toma por defecto WordPress para mostrar páginas estáticas.
		</p>
	</article>
');
get_template_part('content');
get_sidebar();
get_footer();