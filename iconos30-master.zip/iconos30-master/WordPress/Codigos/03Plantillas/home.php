<?php 
get_header();
print('
	<article class="item  title-template">
		<p>
			El archivo <em>home.php</em> es el archivo que toma por defecto WordPress para mostrar la página de inicio (home) de nuestro sitio.
		</p>
	</article>
');
get_template_part('content');
get_sidebar();
get_footer();