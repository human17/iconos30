		<aside class="item  lg-flex-auto  ph12  lg3  sidebar">
			<?php 
			get_search_form();
			dynamic_sidebar(2);
			dynamic_sidebar(1);
			dynamic_sidebar(3);
			?>
		</aside>