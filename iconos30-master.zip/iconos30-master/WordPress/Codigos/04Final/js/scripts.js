$('a[rel="category tag"]').prepend('<i class="fa  fa-folder-open"></i> ');
$('a[rel="tag"]').prepend('<i class="fa  fa-tag"></i> ');

(function (d, w){
	'use strict';

	var menu = d.querySelector('.main-nav'),
		menuBtn = d.querySelector('.menu-btn'),
		mq = w.matchMedia('(min-width:64em)');

		function closeNav(mq) {
			return (mq.matches) 
				? menu.classList.remove('active')
				: false;
		}

		menuBtn.onclick = function (e) {
			e.preventDefault();
			menu.classList.toggle('active');
		}

		w.onload = closeNav(mq);
		mq.addListener(closeNav);
})(document, window);