<?php 

function agregar_menus_y_destacadas() {
	add_theme_support('post-thumbnails');

	$locations = array(
		'main_nav' => 'Navegación Principal',
		'social_nav' => 'Navegación Redes Sociales'
	);

	register_nav_menus($locations);
}

add_action('after_setup_theme', 'agregar_menus_y_destacadas');

add_filter('excerpt_more', function () {
	$url_post = get_permalink();

	return "<a href='$url_post'> <small>leer más</small> <i class='fa fa-info-circle'></i></a>";
});

add_filter('excerpt_length', function () {
	return 20;
});

add_action('widgets_init', function () {
	register_sidebars(3);
});