<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php bloginfo('name'); ?></title>
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/responsimple.min.css">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
	<?php wp_head(); ?>
</head>
<body>
	<header class="container-full  header">
		<section class="container  lg-flex  lg-flex-wrap">
			<div class="item  lg-flex-auto  ph12  lg2  logo">
				<a href="<?php bloginfo('home'); ?>">
					<h1><?php bloginfo('name'); ?></h1>
				</a>
			</div>
			<nav class="item  lg-flex-auto  ph12  lg10  menu  main-nav">
				<p>Menú</p>
			</nav>
		</section>
	</header>
	<main class="container  lg-flex  lg-flex-wrap  main">