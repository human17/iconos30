$('a[rel="category tag"]').prepend('<i class="fa  fa-folder-open"></i> ');
$('a[rel="tag"]').prepend('<i class="fa  fa-tag"></i> ');