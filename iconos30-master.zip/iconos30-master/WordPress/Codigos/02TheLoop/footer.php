	</main>
	<footer class="container  lg-flex  lg-flex-wrap  footer">
		<div class="item  lg-flex-auto  ph12">
			<p>Footer</p>
		</div>
	</footer>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js" defer></script>
	<script src="<?php bloginfo('template_url'); ?>/js/scripts.js" defer></script>
	<?php wp_footer(); ?>
</body>
</html>