	</main>
	<footer class="container  lg-flex  lg-flex-wrap  footer">
		<div class="item  lg-flex-auto  ph12">
			<p>Footer</p>
		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>