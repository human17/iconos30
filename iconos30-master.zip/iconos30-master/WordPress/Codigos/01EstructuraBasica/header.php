<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php bloginfo('name'); ?></title>
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/responsimple.min.css">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
	<?php wp_head(); ?>
</head>
<body>
	<header class="container-full  header">
		<section class="container  lg-flex  lg-flex-wrap">
			<div class="item  lg-flex-auto  ph12  lg4  logo">
				<a href="#">
					<h1>Logo</h1>
				</a>
			</div>
			<nav class="item  lg-flex-auto  ph12  lg8  menu  main-nav">
				<p>Menú</p>
			</nav>
		</section>
	</header>
	<main class="container  lg-flex  lg-flex-wrap  main">