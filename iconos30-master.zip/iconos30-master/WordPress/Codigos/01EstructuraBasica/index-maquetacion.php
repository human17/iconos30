<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<title><?php bloginfo('name'); ?></title>
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/responsimple.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
</head>
<body>
	<h1>Hola WordPress</h1>
	<h2>Responsimple</h2>
	<section class="container flex flex-wrap">
		<article class="item flex-none ph12 sm6 md4 lg3">
			<p>Elemento 1</p>
		</article>
		<article class="item flex-none ph12 sm6 md4 lg3">
			<p>Elemento 2</p>
		</article>
		<article class="item flex-none ph12 sm6 md4 lg3">
			<p>Elemento 3</p>
		</article>
		<article class="item flex-none ph12 sm6 md4 lg3">
			<p>Elemento 4</p>
		</article>
	</section>
	<h2>Bootstrap</h2>
	<section class="row">
		<article class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
			<p>Elemento 1</p>
		</article>
		<article class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
			<p>Elemento 2</p>
		</article>
		<article class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
			<p>Elemento 3</p>
		</article>
		<article class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
			<p>Elemento 4</p>
		</article>
	</section>
</body>
</html>