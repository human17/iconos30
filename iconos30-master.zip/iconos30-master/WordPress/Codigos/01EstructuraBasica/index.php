<?php 
get_header();
get_header('secundario');
get_template_part('content');
get_sidebar();
get_footer();