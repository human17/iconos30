		<article class="item  lg-flex-auto  ph12  lg9  content">
			<p>Contenido Principal</p>
		</article>