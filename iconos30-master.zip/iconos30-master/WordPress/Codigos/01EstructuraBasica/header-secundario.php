	<header class="container-full  header">
		<section class="container  lg-flex  lg-flex-wrap">
			<div class="item  lg-flex-auto  ph12  lg4  logo">
				<a href="#">
					<h1>Logo Secundario</h1>
				</a>
			</div>
			<nav class="item  lg-flex-auto  ph12  lg8  menu  main-nav">
				<p>Menú Secundario</p>
			</nav>
		</section>
	</header>